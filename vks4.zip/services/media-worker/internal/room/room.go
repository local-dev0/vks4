// Room — агрегат комнаты в media-worker.
package room

import (
	"context"
	"errors"
	"path/filepath"
	"sync"
	"time"

	"github.com/pion/webrtc/v4"
	"go.uber.org/zap"

	"github.com/vks4/vks4/services/media-worker/internal/asd"
	"github.com/vks4/vks4/services/media-worker/internal/layout"
	"github.com/vks4/vks4/services/media-worker/internal/peer"
	"github.com/vks4/vks4/services/media-worker/internal/pipeline"
)

type LayoutMode = layout.Mode

type Room struct {
	ID         string
	mu         sync.RWMutex
	peers      map[string]*peer.Peer
	joinOrder  []string
	pipeline   pipeline.Pipeline
	det        *asd.Detector
	mode       LayoutMode
	recording  bool
	recordPath string
	log        *zap.Logger
	ice        []webrtc.ICEServer
	videoCodec string
	width      int
	height     int
	createdAt  time.Time

	// Маршрутизация RTP-пакетов peer → pipeline.
	videoIn map[string]chan<- []byte
	audioIn map[string]chan<- []byte

	// Egress: pipeline → все peer-ы.
	stopEgress chan struct{}
}

type Options struct {
	ID         string
	Log        *zap.Logger
	Pipeline   pipeline.Pipeline
	ICE        []webrtc.ICEServer
	VideoCodec string
	Width      int
	Height     int
}

func New(opts Options) *Room {
	r := &Room{
		ID:         opts.ID,
		peers:      map[string]*peer.Peer{},
		pipeline:   opts.Pipeline,
		det:        asd.New(-45, 300*time.Millisecond),
		mode:       layout.ModeGrid,
		log:        opts.Log,
		ice:        opts.ICE,
		videoCodec: opts.VideoCodec,
		width:      opts.Width,
		height:     opts.Height,
		videoIn:    map[string]chan<- []byte{},
		audioIn:    map[string]chan<- []byte{},
		stopEgress: make(chan struct{}),
		createdAt:  time.Now(),
	}
	go r.egressLoop()
	go r.asdLoop()
	return r
}

func (r *Room) AddPeer(ctx context.Context, peerID, sdpOffer string) (string, error) {
	r.mu.Lock()
	if _, ok := r.peers[peerID]; ok {
		r.mu.Unlock()
		return "", errors.New("peer exists")
	}
	r.mu.Unlock()

	codec := webrtc.MimeTypeVP8
	if r.videoCodec == "h264" {
		codec = webrtc.MimeTypeH264
	}
	p, err := peer.New(r.ID, peerID, peer.Options{
		ICE: r.ice, Log: r.log, Sink: r, VideoCodec: codec,
	})
	if err != nil {
		return "", err
	}
	videoIn, audioIn, err := r.pipeline.AddPeer(peerID)
	if err != nil {
		_ = p.Close()
		return "", err
	}
	answer, err := p.Negotiate(ctx, sdpOffer)
	if err != nil {
		_ = p.Close()
		_ = r.pipeline.RemovePeer(peerID)
		return "", err
	}

	r.mu.Lock()
	r.peers[peerID] = p
	r.videoIn[peerID] = videoIn
	r.audioIn[peerID] = audioIn
	r.joinOrder = append(r.joinOrder, peerID)
	r.mu.Unlock()
	r.applyLayout()
	return answer, nil
}

func (r *Room) RemovePeer(peerID string) error {
	r.mu.Lock()
	p := r.peers[peerID]
	delete(r.peers, peerID)
	delete(r.videoIn, peerID)
	delete(r.audioIn, peerID)
	r.joinOrder = removeID(r.joinOrder, peerID)
	r.mu.Unlock()
	r.det.Forget(peerID)
	if p != nil {
		_ = p.Close()
	}
	_ = r.pipeline.RemovePeer(peerID)
	r.applyLayout()
	return nil
}

func (r *Room) SetLayout(m LayoutMode) {
	r.mu.Lock()
	r.mode = m
	r.mu.Unlock()
	r.applyLayout()
}

func (r *Room) Layout() LayoutMode {
	r.mu.RLock()
	defer r.mu.RUnlock()
	return r.mode
}

func (r *Room) applyLayout() {
	r.mu.RLock()
	mode := r.mode
	speaker := r.det.Current()
	peers := append([]string(nil), r.joinOrder...)
	width, height := r.width, r.height
	r.mu.RUnlock()
	cells := layout.Compute(layout.Spec{
		Mode: mode, Width: width, Height: height, Speaker: speaker,
	}, peers)
	if err := r.pipeline.UpdateLayout(cells); err != nil {
		r.log.Warn("update layout", zap.String("room", r.ID), zap.Error(err))
	}
}

// OnVideoRTP реализует pipeline.Sink — здесь не нужно отправлять обратно,
// мы только пушим в pipeline через канал. Метод вызывается из peer.onTrack.
func (r *Room) OnVideoRTP(peerID string, pkt []byte) {
	r.mu.RLock()
	ch := r.videoIn[peerID]
	r.mu.RUnlock()
	if ch == nil {
		return
	}
	select {
	case ch <- pkt:
	default:
		// drop, чтобы не блокировать ingress
	}
}

func (r *Room) OnAudioRTP(peerID string, pkt []byte) {
	r.mu.RLock()
	ch := r.audioIn[peerID]
	r.mu.RUnlock()
	if ch == nil {
		return
	}
	select {
	case ch <- pkt:
	default:
	}
}

func (r *Room) egressLoop() {
	for {
		select {
		case <-r.stopEgress:
			return
		case s, ok := <-r.pipeline.VideoOut():
			if !ok {
				return
			}
			r.broadcastVideo(s.Data)
		case s, ok := <-r.pipeline.AudioOut():
			if !ok {
				return
			}
			r.broadcastAudio(s.Data)
		}
	}
}

func (r *Room) asdLoop() {
	for {
		select {
		case <-r.stopEgress:
			return
		case lvl, ok := <-r.pipeline.ASDLevel():
			if !ok {
				return
			}
			if _, changed := r.det.Push(asd.Sample{PeerID: lvl.PeerID, DBFS: lvl.DBFS, When: time.Now()}); changed {
				r.applyLayout()
				// TODO: пушим active-speaker событие в signaling через шину/Redis.
			}
		}
	}
}

func (r *Room) broadcastVideo(pkt []byte) {
	if len(pkt) == 0 {
		return
	}
	r.mu.RLock()
	targets := make([]*peer.Peer, 0, len(r.peers))
	for _, p := range r.peers {
		targets = append(targets, p)
	}
	r.mu.RUnlock()
	for _, p := range targets {
		_ = p.WriteVideoRTP(pkt)
	}
}

func (r *Room) broadcastAudio(pkt []byte) {
	if len(pkt) == 0 {
		return
	}
	r.mu.RLock()
	targets := make([]*peer.Peer, 0, len(r.peers))
	for _, p := range r.peers {
		targets = append(targets, p)
	}
	r.mu.RUnlock()
	for _, p := range targets {
		_ = p.WriteAudioRTP(pkt)
	}
}

func (r *Room) StartRecording(dir string) (string, error) {
	r.mu.Lock()
	if r.recording {
		r.mu.Unlock()
		return r.recordPath, nil
	}
	path := filepath.Join(dir, r.ID+".mp4")
	r.mu.Unlock()
	if err := r.pipeline.StartRecording(path); err != nil {
		return "", err
	}
	r.mu.Lock()
	r.recording = true
	r.recordPath = path
	r.mu.Unlock()
	return path, nil
}

func (r *Room) StopRecording() (string, int64, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if !r.recording {
		return "", 0, nil
	}
	p, size, err := r.pipeline.StopRecording()
	r.recording = false
	return p, size, err
}

func (r *Room) Close(ctx context.Context) error {
	close(r.stopEgress)
	r.mu.Lock()
	peers := make([]*peer.Peer, 0, len(r.peers))
	for _, p := range r.peers {
		peers = append(peers, p)
	}
	r.peers = nil
	r.mu.Unlock()
	for _, p := range peers {
		_ = p.Close()
	}
	return r.pipeline.Stop(ctx)
}

func (r *Room) Snapshot() Snapshot {
	r.mu.RLock()
	defer r.mu.RUnlock()
	return Snapshot{
		ID:           r.ID,
		Participants: len(r.peers),
		Layout:       string(r.mode),
		Recording:    r.recording,
		CreatedAt:    r.createdAt,
	}
}

type Snapshot struct {
	ID           string    `json:"id"`
	Participants int       `json:"participants"`
	Layout       string    `json:"layout"`
	Recording    bool      `json:"recording"`
	CreatedAt    time.Time `json:"createdAt"`
}

func removeID(s []string, id string) []string {
	for i, v := range s {
		if v == id {
			return append(s[:i], s[i+1:]...)
		}
	}
	return s
}
