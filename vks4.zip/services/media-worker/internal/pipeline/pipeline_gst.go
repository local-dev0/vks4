//go:build cgo

package pipeline

import (
	"context"
	"fmt"
	"os"
	"sync"

	"github.com/go-gst/go-gst/gst"
	"github.com/vks4/vks4/services/media-worker/internal/layout"
)

// gstPipeline — конкретная реализация Pipeline на go-gst.
//
// ВАЖНО: код собирается только с CGO и установленным GStreamer 1.20+.
// В этой первой итерации мы делаем структурно полный, но минимально
// рабочий pipeline: один compositor (vmix) + один audiomixer (amix).
// Encoder выбирается из spec.VideoCodec.
type gstPipeline struct {
	spec     Spec
	pipeline *gst.Pipeline

	mu          sync.Mutex
	videoMix    *gst.Element
	audioMix    *gst.Element
	videoSink   *gst.Element
	audioSink   *gst.Element
	tee         *gst.Element
	recBranch   *gst.Bin
	recRunning  bool
	recPath     string

	peers map[string]*peerInputs

	videoOut chan Sample
	audioOut chan Sample
	asdCh    chan ASDLevel

	stopOnce sync.Once
	stopped  chan struct{}
}

type peerInputs struct {
	videoSrc *gst.Element
	audioSrc *gst.Element
	videoIn  chan []byte
	audioIn  chan []byte
}

func NewGstFactory() Factory {
	// gst.Init одноразово на процесс.
	once := sync.Once{}
	return func(spec Spec) (Pipeline, error) {
		var initErr error
		once.Do(func() {
			gst.Init(nil)
		})
		if initErr != nil {
			return nil, initErr
		}
		return newGstPipeline(spec)
	}
}

func newGstPipeline(spec Spec) (*gstPipeline, error) {
	codec := spec.VideoCodec
	if codec == "" {
		codec = "vp8"
	}
	// Сборка через parse_launch — самый практичный путь для динамики.
	videoEnc := "vp8enc target-bitrate=" + itoa(spec.VideoBitrate) + " deadline=1 cpu-used=4 keyframe-max-dist=" + itoa(spec.FPS*2) + " ! rtpvp8pay pt=96"
	if codec == "h264" {
		videoEnc = "x264enc tune=zerolatency speed-preset=veryfast bitrate=" + itoa(spec.VideoBitrate/1000) + " key-int-max=" + itoa(spec.FPS*2) + " ! rtph264pay pt=102 config-interval=-1"
	}
	desc := fmt.Sprintf(
		"compositor name=vmix background=black ! video/x-raw,format=I420,width=%d,height=%d,framerate=%d/1 ! "+
			"tee name=vtee ! queue ! videoconvert ! "+videoEnc+" ! appsink name=vout sync=false emit-signals=true max-buffers=2 drop=true "+
			"vtee. ! queue ! valve name=recv drop=true ! videoconvert ! "+
			" x264enc tune=zerolatency speed-preset=veryfast bitrate=2500 ! mp4mux name=mp4 ! filesink name=fsink location=/dev/null async=false "+
			"audiomixer name=amix latency=20000000 ! audio/x-raw,format=S16LE,channels=2,rate=48000 ! "+
			"tee name=atee ! queue ! audioconvert ! opusenc bitrate="+itoa(spec.AudioBitrate)+" ! rtpopuspay pt=111 ! appsink name=aout sync=false emit-signals=true max-buffers=4 drop=true "+
			"atee. ! queue ! valve name=reca drop=true ! audioconvert ! voaacenc ! mp4.",
		spec.Width, spec.Height, spec.FPS)

	pl, err := gst.NewPipelineFromString(desc)
	if err != nil {
		return nil, fmt.Errorf("parse pipeline: %w", err)
	}
	get := func(name string) *gst.Element {
		el, _ := pl.GetElementByName(name)
		return el
	}
	g := &gstPipeline{
		spec:      spec,
		pipeline:  pl,
		videoMix:  get("vmix"),
		audioMix:  get("amix"),
		videoSink: get("vout"),
		audioSink: get("aout"),
		peers:     map[string]*peerInputs{},
		videoOut:  make(chan Sample, 32),
		audioOut:  make(chan Sample, 64),
		asdCh:     make(chan ASDLevel, 128),
		stopped:   make(chan struct{}),
	}
	g.attachAppsinks()
	return g, nil
}

func (p *gstPipeline) attachAppsinks() {
	// Прицепляем new-sample callback к appsink-ам и пушим Sample в каналы.
	// (В go-gst v1.4: AppSink.SetCallbacks или signal "new-sample".)
	if p.videoSink == nil || p.audioSink == nil {
		return
	}
	p.videoSink.Connect("new-sample", func(sink *gst.Element) gst.FlowReturn {
		s, err := sink.Emit("pull-sample")
		if err != nil || s == nil {
			return gst.FlowOK
		}
		// В go-gst v1.4 sample обёртка: тут пропускаем извлечение buffer для простоты.
		// Реальное копирование data в []byte — TODO (см. pipeline_egress.go).
		select {
		case p.videoOut <- Sample{}:
		default:
		}
		return gst.FlowOK
	})
	p.audioSink.Connect("new-sample", func(sink *gst.Element) gst.FlowReturn {
		select {
		case p.audioOut <- Sample{}:
		default:
		}
		return gst.FlowOK
	})
}

func (p *gstPipeline) Start(ctx context.Context) error {
	return p.pipeline.SetState(gst.StatePlaying)
}

func (p *gstPipeline) Stop(ctx context.Context) error {
	p.stopOnce.Do(func() { close(p.stopped) })
	return p.pipeline.SetState(gst.StateNull)
}

func (p *gstPipeline) AddPeer(peerID string) (chan<- []byte, chan<- []byte, error) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if _, ok := p.peers[peerID]; ok {
		return nil, nil, fmt.Errorf("peer %s already exists", peerID)
	}
	// Динамически создаём appsrc-video и appsrc-audio, депейлоадер, декодер,
	// видео-scaler и подключаем к compositor/audiomixer.
	// В первой итерации — каркас. См. TODO в pipeline_dynamic.go.
	pi := &peerInputs{
		videoIn: make(chan []byte, 256),
		audioIn: make(chan []byte, 256),
	}
	p.peers[peerID] = pi
	return pi.videoIn, pi.audioIn, nil
}

func (p *gstPipeline) RemovePeer(peerID string) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	if pi, ok := p.peers[peerID]; ok {
		close(pi.videoIn)
		close(pi.audioIn)
		delete(p.peers, peerID)
	}
	return nil
}

func (p *gstPipeline) VideoOut() <-chan Sample    { return p.videoOut }
func (p *gstPipeline) AudioOut() <-chan Sample    { return p.audioOut }
func (p *gstPipeline) ASDLevel() <-chan ASDLevel { return p.asdCh }

func (p *gstPipeline) UpdateLayout(cells []layout.Cell) error {
	if p.videoMix == nil {
		return nil
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	// Каждый peer соответствует sink_N (по порядку добавления).
	// Здесь — заглушка: реальное обновление xpos/ypos/width/height на pad-ах compositor.
	// TODO: маппинг peerID → pad index.
	return nil
}

func (p *gstPipeline) StartRecording(filename string) error {
	if filename == "" {
		return fmt.Errorf("filename required")
	}
	if err := os.MkdirAll(parentDir(filename), 0o755); err != nil {
		return err
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	recv, _ := p.pipeline.GetElementByName("recv")
	reca, _ := p.pipeline.GetElementByName("reca")
	fs, _ := p.pipeline.GetElementByName("fsink")
	if fs == nil {
		return fmt.Errorf("filesink not found")
	}
	_ = fs.SetProperty("location", filename)
	if recv != nil {
		_ = recv.SetProperty("drop", false)
	}
	if reca != nil {
		_ = reca.SetProperty("drop", false)
	}
	p.recRunning = true
	p.recPath = filename
	return nil
}

func (p *gstPipeline) StopRecording() (string, int64, error) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if !p.recRunning {
		return "", 0, nil
	}
	recv, _ := p.pipeline.GetElementByName("recv")
	reca, _ := p.pipeline.GetElementByName("reca")
	if recv != nil {
		_ = recv.SetProperty("drop", true)
	}
	if reca != nil {
		_ = reca.SetProperty("drop", true)
	}
	p.recRunning = false
	st, err := os.Stat(p.recPath)
	var size int64
	if err == nil {
		size = st.Size()
	}
	return p.recPath, size, nil
}

func itoa(i int) string {
	if i == 0 {
		return "0"
	}
	n := 0
	x := i
	if x < 0 {
		x = -x
	}
	for x > 0 {
		x /= 10
		n++
	}
	neg := i < 0
	buf := make([]byte, n+boolInt(neg))
	x = i
	if neg {
		buf[0] = '-'
		x = -x
	}
	for j := len(buf) - 1; j >= boolInt(neg); j-- {
		buf[j] = byte('0' + x%10)
		x /= 10
	}
	return string(buf)
}

func boolInt(b bool) int {
	if b {
		return 1
	}
	return 0
}

func parentDir(p string) string {
	for i := len(p) - 1; i >= 0; i-- {
		if p[i] == '/' || p[i] == '\\' {
			return p[:i]
		}
	}
	return "."
}
