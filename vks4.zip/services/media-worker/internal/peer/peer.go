// Peer — обёртка вокруг Pion PeerConnection.
package peer

import (
	"context"
	"fmt"
	"io"
	"sync"

	"github.com/pion/interceptor"
	"github.com/pion/webrtc/v4"
	"go.uber.org/zap"
)

type Sink interface {
	OnVideoRTP(peerID string, pkt []byte)
	OnAudioRTP(peerID string, pkt []byte)
}

type Peer struct {
	ID     string
	RoomID string

	pc       *webrtc.PeerConnection
	cfg      webrtc.Configuration
	log      *zap.Logger
	sink     Sink

	videoLocal *webrtc.TrackLocalStaticRTP
	audioLocal *webrtc.TrackLocalStaticRTP

	mu     sync.Mutex
	closed bool
}

type Options struct {
	ICE        []webrtc.ICEServer
	Log        *zap.Logger
	Sink       Sink
	VideoCodec string // mime: video/VP8 | video/H264
}

func New(roomID, peerID string, opts Options) (*Peer, error) {
	mediaEngine := &webrtc.MediaEngine{}
	if err := mediaEngine.RegisterDefaultCodecs(); err != nil {
		return nil, fmt.Errorf("register codecs: %w", err)
	}
	registry := &interceptor.Registry{}
	if err := webrtc.RegisterDefaultInterceptors(mediaEngine, registry); err != nil {
		return nil, fmt.Errorf("interceptors: %w", err)
	}
	api := webrtc.NewAPI(
		webrtc.WithMediaEngine(mediaEngine),
		webrtc.WithInterceptorRegistry(registry),
	)
	pc, err := api.NewPeerConnection(webrtc.Configuration{ICEServers: opts.ICE})
	if err != nil {
		return nil, fmt.Errorf("new pc: %w", err)
	}
	codec := opts.VideoCodec
	if codec == "" {
		codec = webrtc.MimeTypeVP8
	}
	videoLocal, err := webrtc.NewTrackLocalStaticRTP(webrtc.RTPCodecCapability{MimeType: codec}, "mcu-video-"+peerID, "mcu")
	if err != nil {
		return nil, err
	}
	audioLocal, err := webrtc.NewTrackLocalStaticRTP(webrtc.RTPCodecCapability{MimeType: webrtc.MimeTypeOpus}, "mcu-audio-"+peerID, "mcu")
	if err != nil {
		return nil, err
	}
	if _, err := pc.AddTrack(videoLocal); err != nil {
		return nil, err
	}
	if _, err := pc.AddTrack(audioLocal); err != nil {
		return nil, err
	}
	p := &Peer{
		ID: peerID, RoomID: roomID, pc: pc, log: opts.Log, sink: opts.Sink,
		videoLocal: videoLocal, audioLocal: audioLocal,
	}
	pc.OnTrack(p.onTrack)
	pc.OnICEConnectionStateChange(func(s webrtc.ICEConnectionState) {
		opts.Log.Debug("ice state", zap.String("peer", peerID), zap.String("state", s.String()))
	})
	pc.OnConnectionStateChange(func(s webrtc.PeerConnectionState) {
		opts.Log.Info("pc state", zap.String("peer", peerID), zap.String("state", s.String()))
		if s == webrtc.PeerConnectionStateFailed || s == webrtc.PeerConnectionStateClosed {
			_ = p.Close()
		}
	})
	return p, nil
}

func (p *Peer) onTrack(track *webrtc.TrackRemote, _ *webrtc.RTPReceiver) {
	go func() {
		buf := make([]byte, 1500)
		isVideo := track.Kind() == webrtc.RTPCodecTypeVideo
		for {
			n, _, err := track.Read(buf)
			if err != nil {
				if err != io.EOF {
					p.log.Debug("track read", zap.Error(err))
				}
				return
			}
			pkt := make([]byte, n)
			copy(pkt, buf[:n])
			if isVideo {
				if p.sink != nil {
					p.sink.OnVideoRTP(p.ID, pkt)
				}
			} else {
				if p.sink != nil {
					p.sink.OnAudioRTP(p.ID, pkt)
				}
			}
		}
	}()
}

// Negotiate выполняет SDP-handshake: принимает offer от клиента, возвращает answer.
func (p *Peer) Negotiate(ctx context.Context, offerSDP string) (string, error) {
	offer := webrtc.SessionDescription{Type: webrtc.SDPTypeOffer, SDP: offerSDP}
	if err := p.pc.SetRemoteDescription(offer); err != nil {
		return "", fmt.Errorf("set remote: %w", err)
	}
	gatherDone := webrtc.GatheringCompletePromise(p.pc)
	answer, err := p.pc.CreateAnswer(nil)
	if err != nil {
		return "", fmt.Errorf("create answer: %w", err)
	}
	if err := p.pc.SetLocalDescription(answer); err != nil {
		return "", fmt.Errorf("set local: %w", err)
	}
	<-gatherDone
	return p.pc.LocalDescription().SDP, nil
}

// WriteVideoRTP пушит закодированный RTP-пакет в egress трек peer-а.
func (p *Peer) WriteVideoRTP(pkt []byte) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.closed {
		return nil
	}
	_, err := p.videoLocal.Write(pkt)
	return err
}

func (p *Peer) WriteAudioRTP(pkt []byte) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.closed {
		return nil
	}
	_, err := p.audioLocal.Write(pkt)
	return err
}

func (p *Peer) Close() error {
	p.mu.Lock()
	if p.closed {
		p.mu.Unlock()
		return nil
	}
	p.closed = true
	p.mu.Unlock()
	return p.pc.Close()
}
