package ws

import (
	"net/http"

	"github.com/coder/websocket"
	"go.uber.org/zap"

	"github.com/vks4/vks4/services/signaling/internal/auth"
	"github.com/vks4/vks4/services/signaling/internal/mediarpc"
	"github.com/vks4/vks4/services/signaling/internal/session"
)

type Handler struct {
	hub      *session.Hub
	media    mediarpc.Client
	verifier *auth.Verifier
	log      *zap.Logger
}

func NewHandler(hub *session.Hub, media mediarpc.Client, verifier *auth.Verifier, log *zap.Logger) *Handler {
	return &Handler{hub: hub, media: media, verifier: verifier, log: log}
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	conn, err := websocket.Accept(w, r, &websocket.AcceptOptions{
		InsecureSkipVerify: true, // TLS у Caddy; внутри сети ок
		Subprotocols:       []string{"vks4.signaling.v1"},
	})
	if err != nil {
		h.log.Warn("ws accept", zap.Error(err))
		return
	}
	// mediarpc.Client совпадает по сигнатуре с session.MediaClient.
	sess := session.New(conn, h.hub, h.media, h.verifier, h.log)
	ctx := r.Context()
	if err := sess.Run(ctx); err != nil {
		h.log.Debug("ws closed", zap.Error(err))
	}
}
