import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { DndContext, type DragEndEvent, useDraggable } from "@dnd-kit/core";
import { RoomsApi, type Layout } from "@/features/rooms/api";

const LAYOUT_MODES = ["grid", "active_speaker", "lecture", "pip", "custom"] as const;

export function LayoutEditor() {
  const { id = "" } = useParams();
  const nav = useNavigate();
  const qc = useQueryClient();
  const room = useQuery({ queryKey: ["room", id], queryFn: () => RoomsApi.get(id), enabled: !!id });

  const [layout, setLayout] = useState<Layout>({
    mode: "grid", width: 1280, height: 720, cells: [],
  });

  useEffect(() => {
    if (room.data?.defaultLayout) {
      setLayout({
        ...room.data.defaultLayout,
        width: room.data.defaultLayout.width ?? 1280,
        height: room.data.defaultLayout.height ?? 720,
        cells: room.data.defaultLayout.cells ?? [],
      });
    }
  }, [room.data]);

  const save = useMutation({
    mutationFn: () => RoomsApi.layout(id, layout),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["room", id] });
      nav(`/rooms/${id}`);
    },
  });

  function onDragEnd(e: DragEndEvent) {
    const idCell = e.active.id as string;
    setLayout((prev) => {
      const cells = (prev.cells ?? []).map((c) =>
        c.id === idCell ? { ...c, x: c.x + e.delta.x, y: c.y + e.delta.y } : c,
      );
      return { ...prev, cells };
    });
  }

  function addCell() {
    setLayout((p) => ({
      ...p,
      cells: [...(p.cells ?? []), { id: `cell-${(p.cells?.length ?? 0) + 1}`, x: 10, y: 10, w: 320, h: 180 }],
    }));
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold tracking-tight">Layout editor</h1>
        <div className="flex gap-2">
          <button className="btn-ghost" onClick={addCell}>+ Cell</button>
          <button className="btn-primary" onClick={() => save.mutate()} disabled={save.isPending}>Save</button>
        </div>
      </div>

      <div className="grid grid-cols-[18rem_1fr] gap-4">
        <aside className="card p-4 space-y-3">
          <label className="block">
            <span className="text-sm">Mode</span>
            <select className="input mt-1" value={layout.mode} onChange={(e) => setLayout({ ...layout, mode: e.target.value as Layout["mode"] })}>
              {LAYOUT_MODES.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </label>
          <div className="grid grid-cols-2 gap-2">
            <label className="block">
              <span className="text-sm">Width</span>
              <input className="input mt-1" type="number" value={layout.width} onChange={(e) => setLayout({ ...layout, width: +e.target.value })} />
            </label>
            <label className="block">
              <span className="text-sm">Height</span>
              <input className="input mt-1" type="number" value={layout.height} onChange={(e) => setLayout({ ...layout, height: +e.target.value })} />
            </label>
          </div>
          <label className="block">
            <span className="text-sm">Background</span>
            <input className="input mt-1" type="color" value={layout.background?.color ?? "#000000"}
              onChange={(e) => setLayout({ ...layout, background: { ...layout.background, color: e.target.value } })} />
          </label>
          <label className="block">
            <span className="text-sm">Logo URL</span>
            <input className="input mt-1" placeholder="https://…"
              value={layout.logo?.url ?? ""}
              onChange={(e) => setLayout({ ...layout, logo: { ...layout.logo, url: e.target.value } })} />
          </label>
        </aside>

        <div
          className="card relative overflow-hidden"
          style={{
            width: layout.width, height: layout.height,
            background: layout.background?.color ?? "#000",
            backgroundImage: layout.background?.url ? `url(${layout.background.url})` : undefined,
            backgroundSize: "cover",
          }}
        >
          <DndContext onDragEnd={onDragEnd}>
            {(layout.cells ?? []).map((c) => (
              <DraggableCell key={c.id} cell={c} />
            ))}
          </DndContext>
          {layout.logo?.url && (
            <img src={layout.logo.url} alt="logo"
                 style={{ position: "absolute", left: layout.logo.x, top: layout.logo.y, width: layout.logo.w, height: layout.logo.h }} />
          )}
        </div>
      </div>
    </div>
  );
}

function DraggableCell({ cell }: { cell: { id: string; x: number; y: number; w: number; h: number } }) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({ id: cell.id });
  const style: React.CSSProperties = {
    position: "absolute",
    left: cell.x,
    top: cell.y,
    width: cell.w,
    height: cell.h,
    transform: transform ? `translate(${transform.x}px, ${transform.y}px)` : undefined,
  };
  return (
    <div ref={setNodeRef} style={style} {...listeners} {...attributes}
         className="border-2 border-brand-500/70 bg-brand-500/20 rounded text-xs text-white flex items-center justify-center cursor-move select-none">
      {cell.id}
    </div>
  );
}
