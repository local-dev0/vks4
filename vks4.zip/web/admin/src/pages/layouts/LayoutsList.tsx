import { Link } from "react-router-dom";

export function LayoutsList() {
  // В первой итерации layout-ы привязаны к комнатам напрямую.
  // Здесь — лендинг с описанием и переходом к комнатам.
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold tracking-tight">Layouts</h1>
      <p className="text-slate-600 dark:text-slate-300">
        Layouts задаются на уровне комнаты. Откройте конкретную комнату и нажмите
        «Layout» для drag-and-drop редактора.
      </p>
      <Link to="/rooms" className="btn-primary">Go to rooms</Link>
    </div>
  );
}
