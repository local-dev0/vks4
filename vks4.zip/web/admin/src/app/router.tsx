import { createBrowserRouter } from "react-router-dom";
import { AppShell } from "./layout/AppShell";
import { Guard } from "@/features/auth/Guard";
import { Login } from "@/pages/login/Login";
import { Dashboard } from "@/pages/dashboard/Dashboard";
import { RoomsList } from "@/pages/rooms/RoomsList";
import { RoomDetail } from "@/pages/rooms/RoomDetail";
import { RoomCreate } from "@/pages/rooms/RoomCreate";
import { LayoutEditor } from "@/pages/layouts/LayoutEditor";
import { LayoutsList } from "@/pages/layouts/LayoutsList";
import { UsersPage } from "@/pages/users/Users";
import { Recordings } from "@/pages/recordings/Recordings";
import { Monitoring } from "@/pages/monitoring/Monitoring";
import { Logs } from "@/pages/logs/Logs";
import { SettingsPage } from "@/pages/settings/Settings";

export const router = createBrowserRouter([
  { path: "/login", element: <Login /> },
  {
    path: "/",
    element: <Guard><AppShell /></Guard>,
    children: [
      { index: true, element: <Dashboard /> },
      { path: "rooms",            element: <RoomsList /> },
      { path: "rooms/new",        element: <RoomCreate /> },
      { path: "rooms/:id",        element: <RoomDetail /> },
      { path: "rooms/:id/layout", element: <LayoutEditor /> },
      { path: "layouts",          element: <LayoutsList /> },
      { path: "recordings",       element: <Recordings /> },
      { path: "users",            element: <Guard roles={["admin"]}><UsersPage /></Guard> },
      { path: "monitoring",       element: <Monitoring /> },
      { path: "logs",             element: <Logs /> },
      { path: "settings",         element: <Guard roles={["admin"]}><SettingsPage /></Guard> },
    ],
  },
]);
